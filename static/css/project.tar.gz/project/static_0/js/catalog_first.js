updateCatalog("",true)
